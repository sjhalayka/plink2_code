#include <simde/simde-common.h>

#if (SIMDE_VERSION_MAJOR*100000 + SIMDE_VERSION_MINOR*100 + SIMDE_VERSION_MICRO) < 702
#  error simde version too old
#endif
