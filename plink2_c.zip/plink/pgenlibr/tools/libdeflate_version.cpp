#include <libdeflate.h>

#if (LIBDEFLATE_VERSION_MAJOR*1000 + LIBDEFLATE_VERSION_MINOR) < 1009
#  error libdeflate version too old
#endif
