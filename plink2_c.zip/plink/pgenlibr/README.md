See https://CRAN.R-project.org/package=pgenlibr .
